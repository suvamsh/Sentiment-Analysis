import os,re

"""
Update these two variables for this to work.  first put in all the names
you use with pidgin.  if you have an alias, you'll need to use that instead
of the screen name

then point it to the purple config directory (or wherever you store your
pidgin log files)
"""

chat_names = ('camel', 'billy@loud3r.com', 'novembercamel@gmail.com',
              'mrbillymcclure')
purple_dir = '~/.purple/logs/'
output_file = 'words.txt'

# ALWAYS USE THIS FORMAT WHEN ADDING A REGULAR EXPRESSION
# group(1) = date
# group(2) = name
# group(3) = message
reges = {
  'pidgin_text_log': '(\(.*?\)) (.*?)\: (.*)',
  'pidgin_html_log': '.*?(\(.*?\)).*?\<b\>(.*?)\:\<\/b\>\<\/font\>(.*?)\<br\/\>'
}
search_expression = reges['pidgin_html_log']


def dirEntries(dir_name, subdir, *args):
  fileList = []
  for file in os.listdir(dir_name):
    dirfile = os.path.join(dir_name, file)
    if os.path.isfile(dirfile):
      if not args:
        fileList.append(dirfile)
      else:
        if os.path.splitext(dirfile)[1][1:] in args:
          fileList.append(dirfile)
    # recursively access file names in subdirectories
    elif os.path.isdir(dirfile) and subdir:
      print "Accessing directory:", dirfile
      fileList.extend(dirEntries(dirfile, subdir, *args))
  return fileList

file_list = dirEntries(purple_dir, True)
words_file = open(output_file, 'w')
for fh in [f for f in file_list if f.find('/.system') is -1]:
  fh = open(fh)
  for line in fh:
    m = re.search(search_expression, line)
    if not m: continue # not a line of chat
    written = False
    for name in chat_names:
      if name.find(m.group(2)) is not -1 and written is False: #name is in name column
        words_file.write("%s\n"%m.group(3))
        written = True
  fh.close
words_file.close  
